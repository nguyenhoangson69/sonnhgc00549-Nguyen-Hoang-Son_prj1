
package dsa.assignment1.model;
import dsa.assignment1.menu.Manager;
//      About a customer:
//1.	ccode (string): the code of the customer (this should be unique for the customer).
//2.	cus_name (string): the name of the customer.
//3.	phone (string): The phone number of the customer (must contain digits only).

public class Customer implements Comparable {
    public String ccode;
    public String cus_name;
    public String phone;

    public Customer(String ccode, String cus_name, String phone) {
        this.ccode = ccode;
        this.cus_name = cus_name;
        this.phone = phone;
    }
    
    public Customer(){
    
    }

    public Customer(String ccode) {
        this.ccode = ccode;
    }
    
    public int compareTo(Object other) {
        return Manager.compareString(this.ccode, ((Customer) other).ccode);
    }
}
