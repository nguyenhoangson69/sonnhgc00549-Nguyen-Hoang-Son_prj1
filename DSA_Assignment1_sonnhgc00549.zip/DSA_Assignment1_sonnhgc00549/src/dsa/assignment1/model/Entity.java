package dsa.assignment1.model;

import java.util.ArrayList;

import java.io.Serializable;

/**
 *
 * @author TungDS
 */
public class Entity implements Serializable {

    public ArrayList<Customer> customers;
    public ArrayList<Product> products;
    public ArrayList<Ordering> orderings;

}
