
package dsa.assignment1.model;
import dsa.assignment1.menu.Manager;

//1.	pcode (string): the code of the product to be ordered.
//2.	ccode (string): the code of the customer.
//3.	quantity (integer): the number of  ordered products.
//
public class Ordering implements Comparable<Object>{
    public String pcode;
    public String ccode;
    public int quantity;

    public Ordering(String pcode, String ccode, int quantity) {
        this.pcode = pcode;
        this.ccode = ccode;
        this.quantity = quantity;
    }
    
    public String getCombineCode() {
        return pcode + ccode;
    }
    
    public Ordering(){
    
    }
    
    @Override
    public int compareTo(Object other) {
        Ordering orderOther = (Ordering) other;
        return Manager.compareString(this.getCombineCode(), orderOther.getCombineCode());
    }
}
