
package dsa.assignment1.model;

//        About a product:

import dsa.assignment1.menu.*;

//1.	pcode (string): the code of the product (this should be unique for the product).
//2.	pro_name (string): the name of the product.
//3.	quantity (integer): the number of  products with the same code in a shop at beginning of a day.
//4.	saled (integer): the number of  products with the same code, which are saled in the day. Condition: saled ≤ quantity.
//5.	price (double): The price of the product.

public class Product implements Comparable {
    public  String pcode;
    public  String pname;
    public int quantity ;
    public int saled;
    public double price;
    
    public Product(){
    }

    public Product(String pcode, String pro_name, int quantity, int saled, double price) {
        this.pcode = pcode;
        this.pname = pro_name;
        this.quantity = quantity;
        this.saled = saled;
        this.price = price;
    }
    
    public Product(String pcode) {
        this.pcode = pcode;
    }
    
     @Override
    public int compareTo(Object other) {
        return Manager.compareString(this.pcode, ((Product) other).pcode);
    }

}
