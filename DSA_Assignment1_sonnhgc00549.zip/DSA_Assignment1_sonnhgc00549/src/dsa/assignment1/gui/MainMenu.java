
package dsa.assignment1.gui;

import dsa.assignment1.menu.FileMenu;
import dsa.assignment1.menu.Manager;
import dsa.assignment1.model.Customer;
import dsa.assignment1.model.Entity;
import dsa.assignment1.model.Product;
import dsa.assignment1.panels.ProductPanel;
import dsa.assignment1.model.Ordering;
import java.awt.BorderLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import dsa.assignment1.panels.*;

/**
 *
 * @author admin
 */
public class MainMenu extends javax.swing.JFrame {

    private Entity entities;

    private JPanel lastPanelAdded;
    
    public MainMenu() {
        initComponents();
        
        entities = new Entity();
        entities.customers = new ArrayList<>();
        entities.orderings = new ArrayList<>();
        entities.products = new ArrayList<>();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        btnSaveData = new javax.swing.JMenuItem();
        btnLoadData = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        btnProduct = new javax.swing.JMenuItem();
        btnCustomer = new javax.swing.JMenuItem();
        btnOrdering = new javax.swing.JMenuItem();

        jMenu3.setText("File");
        jMenuBar2.add(jMenu3);

        jMenu4.setText("Edit");
        jMenuBar2.add(jMenu4);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jMenu1.setText("File");

        btnSaveData.setText("SaveData");
        btnSaveData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveDataActionPerformed(evt);
            }
        });
        jMenu1.add(btnSaveData);

        btnLoadData.setText("LoadData");
        btnLoadData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoadDataActionPerformed(evt);
            }
        });
        jMenu1.add(btnLoadData);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Manager");

        btnProduct.setText("Product");
        btnProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProductActionPerformed(evt);
            }
        });
        jMenu2.add(btnProduct);

        btnCustomer.setText("Customer");
        btnCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCustomerActionPerformed(evt);
            }
        });
        jMenu2.add(btnCustomer);

        btnOrdering.setText("Ordering");
        btnOrdering.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOrderingActionPerformed(evt);
            }
        });
        jMenu2.add(btnOrdering);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 278, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSaveDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveDataActionPerformed
        // TODO add your handling code here:
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        int result = fileChooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            try {
                FileMenu.saveData(fileToSave.getAbsolutePath(), entities);
            } catch (IOException ex) {
                Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(this, "Success");
        }
        
    }//GEN-LAST:event_btnSaveDataActionPerformed

    private void btnLoadDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoadDataActionPerformed
        // TODO add your handling code here:
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();

            try {
                entities = FileMenu.loadData(selectedFile.getAbsolutePath());
            } catch (FileNotFoundException ex) {
                Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
            }

            if (entities.customers == null) {
                entities.customers = new ArrayList<Customer>();
            } else {
                Manager.shuffleArray(entities.customers);
            }

            if (entities.orderings == null) {
                entities.orderings = new ArrayList<Ordering>();
            } else {
                Manager.shuffleArray(entities.orderings);
            }

            if (entities.products == null) {
                entities.products = new ArrayList<>();

            } else {
                Manager.shuffleArray(entities.products);

            }

            JOptionPane.showMessageDialog(this, "Success");
        }
    }//GEN-LAST:event_btnLoadDataActionPerformed

    private void btnProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProductActionPerformed
        // TODO add your handling code here:
        addNewPanel(new ProductPanel(entities));
    }//GEN-LAST:event_btnProductActionPerformed

    private void btnCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCustomerActionPerformed
        // TODO add your handling code here:
        addNewPanel(new CustomerPanel(entities));
    }//GEN-LAST:event_btnCustomerActionPerformed

    private void btnOrderingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOrderingActionPerformed
        // TODO add your handling code here:
        if (entities.customers.isEmpty() || entities.products.size() == 0) {
            JOptionPane.showMessageDialog(this, "product or customer is empty");
            return;
        }
        addNewPanel(new OrderingPanel(entities));
    }//GEN-LAST:event_btnOrderingActionPerformed

    private void addNewPanel(JPanel panelManager) {

        if (lastPanelAdded != null) {
            remove(lastPanelAdded);
        }

        setLayout(new BorderLayout());
        add(panelManager);
        pack();

        lastPanelAdded = panelManager;
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem btnCustomer;
    private javax.swing.JMenuItem btnLoadData;
    private javax.swing.JMenuItem btnOrdering;
    private javax.swing.JMenuItem btnProduct;
    private javax.swing.JMenuItem btnSaveData;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuBar jMenuBar2;
    // End of variables declaration//GEN-END:variables
}
