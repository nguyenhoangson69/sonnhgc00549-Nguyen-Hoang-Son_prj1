/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsa.assignment1.menu;

import dsa.assignment1.model.Entity;
import java.io.IOException;
import com.google.gson.Gson;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;

/**
 *
 * @author admin
 */
public class FileMenu {
    public  static void saveData(String filePath, Entity entities)throws IOException{
        Gson gson = new Gson();
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter( new FileWriter( filePath));
            writer.write( gson.toJson(entities));
        } catch (IOException e) {
        }
        finally{
            try {
                if ( writer != null)
                writer.close();
            } catch (IOException e) {
            }
        }
    }
    
    public static Entity loadData(String filePath) throws FileNotFoundException{
        Gson gson = new Gson();
        Entity result = gson.fromJson(new FileReader(filePath), Entity.class);
        return result;

    }
}
