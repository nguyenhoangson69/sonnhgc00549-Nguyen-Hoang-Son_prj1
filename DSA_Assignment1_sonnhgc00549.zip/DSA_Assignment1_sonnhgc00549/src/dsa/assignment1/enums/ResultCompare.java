
package dsa.assignment1.enums;
/**
 *
 * @author admin
 */
public class ResultCompare {
    public static final int LESS =-1;
    public static final int EQUAL =0;
    public static final int GREATER =1;
}
