
package dsa.assignment1.enums;

/**
 *
 * @author admin
 */
public enum TypeEdit {
    CREATE, EDIT
}
